You are starting a new project: Courtly, an iOS app for finding tennis partners. Read design_handoff_courtly/README.md and SPEC.md first, then open the two HTML files in a browser to see every screen.

PHASE 1 — SYSTEM DESIGN ONLY. Do not write app code yet. Produce docs/system-design.md covering, for each feature, how it works end to end and why:

1. Architecture: client (SwiftUI), backend choice (recommend one: Supabase/Postgres + realtime, or Firebase), auth (Sign in with Apple, Google, email OTP), hosting, cost at 0–5k users.
2. Data model: full schema for users, hits, courts, hit_requests, friendships, chats, chat_members, messages (incl. hit-request card messages), reports, blocks, device_tokens, notifications. Indexes. Row-level security rules.
3. Hit lifecycle: open → requests → accept → confirmed → played/cancelled; group-chat hit-request cards where first "I'm in" fills a spot atomically (race conditions); expiry; who-can-join visibility (anyone vs friends); radius queries by ZIP/lat-lng.
4. Friends: friendship model (mutual), contact matching by phone hash, suggestions (mutuals, shared group chats, people you hit with), auto-create DM on friend add, block semantics (hide everywhere, both directions).
5. Chat: realtime delivery, message types (text, hit-request card, system), unread counts, pinned hit in hit chats, pagination, offline queue, push for messages. Compare to how Instagram/WhatsApp structure inbox + threads.
6. Notifications: APNs, which events send (requests, accepts, reminders day-before and 1h, cancellations, day-after check), deep links to screens, badge counts.
7. Availability + calendar: 7×3 grid storage, Google/Apple calendar read for "busy", how "Free when you are" and "Usually free Thu" are computed.
8. Feed ranking for Play: From friends first, then Near you sorted by distance; what's cached.
9. Performance: cold start under 1s to first paint; what loads before the Play tab renders, local cache (SwiftData/GRDB), image caching, prefetch on launch, skeleton states.
10. Moderation & App Store: in-app account deletion (cascade), block/report, 18+ check, privacy manifest, required permissions copy.
11. Open questions for me, with your recommended default for each.

Keep each section concrete: tables, sequence diagrams in text, and the exact queries for the hot paths. Then stop and ask me to approve before Phase 2 (building the app).