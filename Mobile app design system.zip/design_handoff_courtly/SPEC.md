# Courtly — handoff spec

iOS app. Adult recreational tennis, Palm Beach County. The unit is a **hit**: one time, one public court, one format, one or more open spots. No feed, no swiping, no messaging before a plan exists.

Design file: `Courtly Play Tab v2.dc.html` (all app screens, newest turn on top; onboarding appended at the bottom). Standalone onboarding: `Courtly Onboarding.dc.html`.

## Visual system
- Font: SF Pro (system). Times/levels in SF Pro Rounded bold.
- Sizes: large title 34/700, screen title 30/700, section header 17/600, body 17, secondary 15 (#5B6577), caption 13.
- Colors: ink #0E1726, secondary #5B6577, grouped bg #F4F5F7, separators #E6E8EC, card #FFFFFF, blue #1F5BD8, blue tint #EAF0FC, green #2F7D57 (confirmed), red #C2532F (destructive).
- Shapes: cards 16px radius, inset grouped lists, primary button 52px / 14px radius, pill buttons 999px, sheets 20px top radius with grabber.
- Tab bar: floating glass pill (Play, My Hits, People, You). Plan a hit is a floating pill button bottom-right on Play only.
- Avatars are photos (striped circles in mocks = photo placeholder). Initials only for people not on Courtly.

## Tabs
- **Play** — hits you can join. Sections: Needs your reply (requests to you, accepted requests), From friends, Near you (closest first). Your own hits never appear here.
- **My Hits** — your commitments. Segments Upcoming / Past. Row states: Open (yours, waiting; shows Invite), Pending (you asked), Confirmed (green).
- **People** — one chat list. Adding a friend creates the chat. Group chats, hit chats, DMs. Header: + (add friends), your photo. Search filters chats only.
- **You** — profile, How you play (Availability, Level, What you play, Area → bottom sheets), Connected (Calendar, Notifications, Account).

## Screen map (ids in design file)
Onboarding (bottom of file, 01–17): welcome → name → photo → birthday → gender → tennis journey → what you play → location (ZIP + miles) → availability (calendar connect or grid) → friends from contacts → account (Google/Apple/email) → notifications pre-prompt + system prompt → You're in.

First run (5a–5g): three coach marks over the real app (Play lists → People + → Plan a hit). Dismissed permanently after step 3. Plan a hit form (5e). Hit posted lands in My Hits (5f).

Core loop (6a–6r):
- 6a push “X asked to join your hit” → 6b request (Accept/Decline) → 6c confirmed hit detail (Chat, Add to calendar, Directions, Cancel hit) → 6d cancel alert → 6e hit chat (hit pinned on top).
- 6f someone else’s hit detail → Ask to join → row shows Pending in My Hits (6g) → 6q accepted banner on Play with Chat.
- 6g My Hits states, 6h empty state.
- 6r day-after check: “Did X show up?” Yes/No, optional Add as friend.

People (4a–4e): 4a chat list, 4b group chat with hit request card (slots, timer, “I’m in” — first tap takes the spot), 4c add friends, 4d Invite sheet (friends or group chat), 4e Request a hit form from the composer.

You (3d, 6i–6m): 6i Availability sheet (grid + calendar manage), 6j Level, 6k What you play (multi), 6l Area (ZIP + 5/10/15/25 mi), 6m Edit profile (photo, first, last).

Safety / App Store (5h–5i, 6n–6p): 5h Account (email, phone, sign-in method, who can see hits, blocked players, policies, Sign out, Delete account) → 5i native delete alert. 6n player profile → “…” → 6o action sheet (Remove friend, Block, Report) → 6p report reasons with “Also block”.

## Data model (minimum)
- User: id, firstName, lastName, photo, birthday, gender, level (beginner|intermediate|advanced), formats[], zip, radiusMi, availability (7×3 grid), calendarConnected, hitsPlayed, friends[], blocked[].
- Hit: id, hostId, startsAt, durationMin, courtId, format, spots, visibility (anyone|friends), status (open|confirmed|cancelled|played), players[], requests[] (userId, status pending|accepted|declined), expiresAt.
- Court: id, name, address, lat/lng, surface, lights.
- Chat: id, type (dm|group|hit), memberIds[], hitId?, messages[] (text | hitRequest card).
- Report: reporterId, reportedId, reason, blocked.

## Rules
- Open hit: anyone matching visibility can Ask to join; host accepts → status confirmed, hit chat created, both get push.
- Hit request card in a group chat: tapping “I’m in” fills a spot immediately (no host approval), card updates for everyone, closes at expiresAt.
- Cancel: host cancels → all players notified; joiner leaves → spot reopens.
- Notifications: requests, accepts, reminders (day before + 1 hr), cancellations, day-after check. Nothing else.
- Others see first name + last initial only.
- Age 18+ enforced from birthday in onboarding.
